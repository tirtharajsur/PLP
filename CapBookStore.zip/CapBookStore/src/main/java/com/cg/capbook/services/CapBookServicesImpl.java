package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Customer;
import com.cg.capbook.daoservices.CustomerDAO;
import com.cg.capbook.exceptions.CustomerDetailsNotFoundException;

@Component("capBookServices")
public class CapBookServicesImpl implements CapBookServices {
	@Autowired
	private CustomerDAO  customerDao;

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		return customerDao.save(customer);
	}

	@Override
	public Customer getCustomerDetails(String emailId) throws CustomerDetailsNotFoundException {
		return customerDao.findById(emailId).orElseThrow(()->new CustomerDetailsNotFoundException("Customer does not exist!!"));
	}

	@Override
	public boolean removeCustomerDetails(String emailId) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
