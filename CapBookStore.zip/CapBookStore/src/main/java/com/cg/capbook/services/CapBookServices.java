package com.cg.capbook.services;

import com.cg.capbook.beans.Customer;
import com.cg.capbook.exceptions.CustomerDetailsNotFoundException;

public interface CapBookServices {
	Customer acceptCustomerDetails(Customer customer);
	Customer getCustomerDetails(String emailId) throws CustomerDetailsNotFoundException;
	boolean removeCustomerDetails(String emailId);

}
